#!/bin/bash
# Usage: log_task.sh "Task Name" "AGENT" "Expected Output" "Output Path" "Priority"
NOTION_TOKEN="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"
TASK_BOARD_ID="32526c87-996c-818a-b9f2-ebd12c4743db"
DEADLINE=$(date -u -d '+30 minutes' '+%Y-%m-%dT%H:%M:%S')

curl -s -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer $NOTION_TOKEN" \
  -H "Content-Type: application/json" \
  -H "Notion-Version: 2022-06-28" \
  -d "{
    \"parent\": {\"database_id\": \"$TASK_BOARD_ID\"},
    \"properties\": {
      \"Task\": {\"title\": [{\"text\": {\"content\": \"$1\"}}]},
      \"Agent\": {\"select\": {\"name\": \"$2\"}},
      \"Status\": {\"select\": {\"name\": \"⚙️ In Progress\"}},
      \"Expected Output\": {\"rich_text\": [{\"text\": {\"content\": \"$3\"}}]},
      \"Output Path\": {\"rich_text\": [{\"text\": {\"content\": \"$4\"}}]},
      \"Priority\": {\"select\": {\"name\": \"$5\"}},
      \"Deadline\": {\"date\": {\"start\": \"$DEADLINE\"}}
    }
  }" | python3 -c "import sys,json; d=json.load(sys.stdin); print('✅ Logged:', d.get('id','failed')[:8])"
